namespace Cinema_Royal_Rodrigo_Araújo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            login login = new login();
            login.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cadrasto cadrasto = new cadrasto();
            cadrasto.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            for (int i = 0; i < 20; i++)
            {
                Button btn = new Button();
                btn.Text = $"Botão {i + 1}";
                btn.Location = new Point(10, 10 + i * 40);
                btn.Size = new Size(150, 35);
                panel1.Controls.Add(btn);
                panel1.AutoScrollMinSize = new Size(0, 800);
            }
        }
    }
}
