﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema_Royal_Rodrigo_Araújo
{
    public partial class principal : Form
    {
        public principal()
        {
            InitializeComponent();
        }
    }
}
